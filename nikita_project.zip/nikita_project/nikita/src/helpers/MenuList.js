
import Download4 from "../assets/download (4).jpeg";
import Download1 from "../assets/download(1).jpeg";
import Download from "../assets/download.jpeg";
import Oppo from "../assets/oppo.jpeg";
import Samsung from "../assets/samsung.jpeg";
import Mob2 from "../assets/mob2.jpeg";
import Mobile1 from "../assets/mobile1.jpeg";
export const MenuList = [
  {
    name: "Samsung",
    image: Download4,
    price: 15.99,
    rating: 2,
  },
  {
    name: "Nokia",
    image: Download1,
    price: 11.99,
    rating: 5,
  },
  {
    name: "One plus",
    image: Download,
    price: 556.53,
    rating: 5,
  },
  {
    name: "Realme",
    image: Oppo,
    price: 17.99,
    rating: 5,
  },
  {
    name: "i-phone",
    image: Mobile1,
    price: 499,
    rating: 5,
  },
  {
    name: "Samsung",
    image: Download1,
    price: 1997.99,
    rating: 5,
  },
  {
    name: "Samsung",
    image: Mob2,
    price: 1997.99,
    rating: 5,
  },
  {
    name: "i-phone",
    image: Samsung,
    price: 4.99,
    rating: 5,
  },
  {
    name: "One plus",
    image: Download,
    price: 556.53,
    rating: 5,
  },

];
